﻿#pragma once

class LibsAndroid
{
public:
	const char * getPlatformABI();
	LibsAndroid();
	~LibsAndroid();
};

