//
//  class1.hpp
//  libLibStatic_iOS
//
//  Created by Alex on 7/5/24.
//

#ifndef class1_hpp
#define class1_hpp

#include <stdio.h>

#endif /* class1_hpp */
