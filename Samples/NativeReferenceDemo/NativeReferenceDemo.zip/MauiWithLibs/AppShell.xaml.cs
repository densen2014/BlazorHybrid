﻿// ********************************** 
// Densen Informatica 中讯科技 
// 作者：Alex Chow
// e-mail:zhouchuanglin@gmail.com 
// **********************************

namespace MauiWithLibs;

public partial class AppShell : Shell
{
    public AppShell()
    {
        InitializeComponent();
    }
}
