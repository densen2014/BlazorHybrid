//
//  LibStatic_iOS.h
//  LibStatic_iOS
//
//  Created by Chow Alex on 6/5/24.
//

#import <Foundation/Foundation.h>

@interface LibStatic_iOS : NSObject
- (int)getClickCount;
@end
